import React from 'react'

function PageNotFound() {
    return (
        <div>
            <h2 style={{color:"red",textAlign:"center"}}> 404..........page not Found </h2>
            <p style={{color:"green",textAlign:"center"}}> try another routing method !!! </p>
        </div>
    )
}

export default PageNotFound
