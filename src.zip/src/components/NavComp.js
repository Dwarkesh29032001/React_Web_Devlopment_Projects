import React from 'react'
import { Link } from 'react-router-dom'

const NavComp=()=>{
    return (
        <div>

            {/* <h2>This is Nav !!</h2> */}

            <Link to="/" className='btn btn-outline-primary btn-sm'>MyImagesComp</Link>
            <Link to="/list" className='btn btn-outline-primary btn-sm'>FavColor</Link>
            <Link to="/frm" className='btn btn-outline-primary btn-sm'>Userform</Link>
            <Link to="/classcomp" className='btn btn-outline-primary btn-sm'>classComp</Link>
            <Link to="/myCss" className='btn btn-outline-primary btn-sm'>MycssComp</Link>
            <Link to="/mystate" className='btn btn-outline-primary btn-sm'>Mystate</Link>
            <Link to="/error" className='btn btn-outline-primary btn-sm'>Error Page</Link>
            <Link to="/Hooks" className='btn btn-outline-primary btn-sm'>ReactHooks</Link>
            <Link to="/DashBoard" className='btn btn-outline-primary btn-sm'>CRUD</Link>
            
        </div>
    )
}

export default NavComp
