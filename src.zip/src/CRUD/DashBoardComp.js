import axios from 'axios';
import React, { useEffect, useState } from 'react'

const DashBoardComp = () => {

    const [product, setproduct] = useState([]);

    useEffect(() => {
        fetchData();
    }, []);

    const fetchData = () => {
        axios.get("http://localhost:8888/product").then((res) => {
            console.log(res.data);
            setproduct(res.data);

        }).catch((err) => { })
    }

    return (
        <div>
            <h2 className='myCRUDHeading'  >This is Dashboard of CRUD Operation Comp</h2>
            <table className='table table-bordered table-hover table-striped'  style={{ border: '5px solid darkblue' }}>

                <thead>

                    <tr>
                        <th>SR.NO.</th> <th>NAME</th> <th>COMPANY</th> <th>PRICE</th> 
                    </tr>

                </thead>

                <tbody>
                    {product.map((val,index)=>{
                        return <tr key={index}>
                            <td>{index+1}</td>
                            <td>{val.name}</td>
                            <td>{val.company}</td>
                            <td>{val.price}</td>
                        </tr>
                    })}
                </tbody>
            </table>
        </div>
    )
}
export default DashBoardComp;