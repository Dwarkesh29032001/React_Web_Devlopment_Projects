
import samosa from '../../assets/images/samosa.jpg'
import dosa from '../../assets/images/dosa.jpg'
import vadapav from '../../assets/images/vadapav.jpg'
import bigImg from '../../assets/images/bigimg-2.jpg'
import bike1 from '../../assets/images/bike1.jpeg';
import bike2 from '../../assets/images/bike2.jpeg';
import GT from '../../assets/images/GT.jpeg';
import gt1 from '../../assets/images/gt1.jpeg';
import bike3 from '../../assets/images/bike3.jpeg';
import bike4 from '../../assets/images/bike4.jpeg';
import bike5 from '../../assets/images/bike5.jpeg';
import bike6 from '../../assets/images/bike6.jpeg';
import bike7 from '../../assets/images/bike7.jpeg';
import thar1 from '../../assets/images/Thar1.jpeg';
import thar2 from '../../assets/images/Thar2.jpeg';
import thar3 from '../../assets/images/Thar3.jpeg';
import thar4 from '../../assets/images/thar4.jpeg';
import supercar from '../../assets/Multimedia/cars.mp4';



const data ={
    samosa,dosa,vadapav,bigImg, bike1 , bike2 , GT , gt1 , bike3 ,bike4 , bike5 , bike6 , bike7 , thar1 , thar2 , thar3 , thar4 , supercar
}
export default data;